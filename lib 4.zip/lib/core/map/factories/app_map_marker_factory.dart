import 'dart:ui' as ui;
import 'package:flutter/services.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

/// Centralized marker creation — replaces duplicated marker construction logic
/// in multiple screens.
class AppMapMarkerFactory {
  AppMapMarkerFactory._();

  /// Marker for rider pickup (origin).
  static Marker origin({
    required String id,
    required LatLng position,
  }) =>
      Marker(
        markerId: MarkerId('origin_$id'),
        position: position,
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
        zIndex: 1,
      );

  /// Marker for rider destination.
  static Marker destination({
    required String id,
    required LatLng position,
  }) =>
      Marker(
        markerId: MarkerId('dest_$id'),
        position: position,
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
        zIndex: 1,
      );

  /// Marker for a driver (car icon).
  static Marker driver({
    required String driverId,
    required LatLng position,
    required BitmapDescriptor icon,
    double rotation = 0,
  }) =>
      Marker(
        markerId: MarkerId('driver_$driverId'),
        position: position,
        icon: icon,
        rotation: rotation,
        anchor: const Offset(0.5, 0.5),
        flat: true,
        zIndex: 2,
      );

  /// Generic custom marker.
  static Marker custom({
    required String id,
    required LatLng position,
    required BitmapDescriptor icon,
    double zIndex = 1,
  }) =>
      Marker(
        markerId: MarkerId(id),
        position: position,
        icon: icon,
        zIndex: zIndex,
      );

  /// Load a car icon from assets — one-liner replaces the 15+ line pattern
  /// duplicated across home screens.
  static Future<BitmapDescriptor> loadCarIcon({
    String assetPath = 'assets/images/carr.png',
    int targetWidth = 40,
  }) async {
    final data = await rootBundle.load(assetPath);
    final bytes = data.buffer.asUint8List();
    final codec =
        await ui.instantiateImageCodec(bytes, targetWidth: targetWidth);
    final frame = await codec.getNextFrame();
    final pngBytes =
        (await frame.image.toByteData(format: ui.ImageByteFormat.png))!
            .buffer
            .asUint8List();
    return BitmapDescriptor.fromBytes(pngBytes);
  }
}
