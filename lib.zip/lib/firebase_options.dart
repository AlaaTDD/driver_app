

import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;


class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        return windows;
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyDeqIgIbEjzwEV6iijrLN9CkL4H2op-rjE',
    appId: '1:741233752146:web:33dc1f9bbf59ae6268878b',
    messagingSenderId: '741233752146',
    projectId: 'arai-449ca',
    authDomain: 'arai-449ca.firebaseapp.com',
    storageBucket: 'arai-449ca.firebasestorage.app',
    measurementId: 'G-NWK1DGRJKM',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyCRw-PPmQ_7iG6T4cRjTa5kTY7T8BBkPzI',
    appId: '1:741233752146:android:0cea4e402b5067a468878b',
    messagingSenderId: '741233752146',
    projectId: 'arai-449ca',
    storageBucket: 'arai-449ca.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyBZvdq0Dfs3-hUX_pnZUf7nnTlInvptp-Q',
    appId: '1:741233752146:ios:27f5ebe06503b65368878b',
    messagingSenderId: '741233752146',
    projectId: 'arai-449ca',
    storageBucket: 'arai-449ca.firebasestorage.app',
    iosClientId: '741233752146-75akd28o15lggvd77essrn4ol5s382t2.apps.googleusercontent.com',
    iosBundleId: 'com.example.taxiApp',
  );

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'AIzaSyBZvdq0Dfs3-hUX_pnZUf7nnTlInvptp-Q',
    appId: '1:741233752146:ios:27f5ebe06503b65368878b',
    messagingSenderId: '741233752146',
    projectId: 'arai-449ca',
    storageBucket: 'arai-449ca.firebasestorage.app',
    iosClientId: '741233752146-75akd28o15lggvd77essrn4ol5s382t2.apps.googleusercontent.com',
    iosBundleId: 'com.example.taxiApp',
  );

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'AIzaSyDeqIgIbEjzwEV6iijrLN9CkL4H2op-rjE',
    appId: '1:741233752146:web:74b47ca31701645368878b',
    messagingSenderId: '741233752146',
    projectId: 'arai-449ca',
    authDomain: 'arai-449ca.firebaseapp.com',
    storageBucket: 'arai-449ca.firebasestorage.app',
    measurementId: 'G-H1MW92XRHB',
  );
}
