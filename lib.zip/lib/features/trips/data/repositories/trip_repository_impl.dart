import 'package:dartz/dartz.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../core/utils/trip_status.dart';
import '../../../../services/supabase_service.dart';
import '../../domain/entities/trip_entity.dart';
import '../../domain/repositories/trip_repository.dart';
import '../models/trip_model.dart';

class TripRepositoryImpl implements TripRepository {
  final _client = SupabaseService.client;

  @override
  Future<Either<String, TripEntity>> createTrip({
    required String userId,
    required String pickupAddress,
    required double pickupLat,
    required double pickupLng,
    required String destinationAddress,
    required double destinationLat,
    required double destinationLng,
    required String vehicleType,
    required double distanceKm,
    required double price,
  }) async {
    try {
      final row = await _client
          .from(AppConstants.tableTrips)
          .insert({
            'user_id': userId,
            'pickup_address': pickupAddress,
            'pickup_lat': pickupLat,
            'pickup_lng': pickupLng,
            'destination_address': destinationAddress,
            'destination_lat': destinationLat,
            'destination_lng': destinationLng,
            'vehicle_type': vehicleType,
            'distance_km': distanceKm,
            'price': price,
            'status': TripStatus.searching.toDbString(),
            'is_paid': false,
          })
          .select()
          .single();
      return Right(TripModel.fromJson(Map<String, dynamic>.from(row)));
    } catch (e) {
      return Left(e.toString());
    }
  }

  @override
  Future<Either<String, List<TripEntity>>> getUserTrips(String userId) async {
    try {
      final rows = await _client
          .from(AppConstants.tableTrips)
          .select()
          .eq('user_id', userId)
          .order('created_at', ascending: false);
      return Right(
        (rows as List)
            .map((row) => TripModel.fromJson(Map<String, dynamic>.from(row)))
            .toList(),
      );
    } catch (e) {
      return Left(e.toString());
    }
  }

  @override
  Future<Either<String, TripEntity?>> getActiveTrip(String userId) async {
    try {
      final row = await _client
          .from(AppConstants.tableTrips)
          .select()
          .eq('user_id', userId)
          .inFilter('status', AppConstants.activeTripStatuses)
          .maybeSingle();
      return Right(
        row == null ? null : TripModel.fromJson(Map<String, dynamic>.from(row)),
      );
    } catch (e) {
      return Left(e.toString());
    }
  }

  @override
  Future<Either<String, void>> cancelTrip({
    required String tripId,
    required String cancelledBy,
    String? cancelReason,
  }) async {
    try {
      final userId = SupabaseService.currentUser?.id;
      if (userId == null) return const Left('errorNotLoggedIn');

      await _client.rpc(
        'cancel_trip',
        params: {
          'p_trip_id': tripId,
          'p_user_id': userId,
          'p_cancelled_by': cancelledBy,
          if (cancelReason != null) 'p_cancel_reason': cancelReason,
        },
      );
      return const Right(null);
    } catch (e) {
      return Left(e.toString());
    }
  }

  @override
  Future<Either<String, void>> updateTripStatus({
    required String tripId,
    required TripStatus newStatus,
  }) async {
    try {
      await _client
          .from(AppConstants.tableTrips)
          .update({'status': newStatus.toDbString()}).eq('id', tripId);
      return const Right(null);
    } catch (e) {
      return Left(e.toString());
    }
  }

  @override
  Future<Either<String, List<TripEntity>>> getAvailableTrips({
    required double lat,
    required double lng,
    required String vehicleType,
  }) async {
    try {
      final rows = await _client
          .from(AppConstants.tableTrips)
          .select()
          .eq('status', TripStatus.searching.toDbString())
          .eq('vehicle_type', vehicleType)
          .order('created_at', ascending: false)
          .limit(50);
      return Right(
        (rows as List)
            .map((row) => TripModel.fromJson(Map<String, dynamic>.from(row)))
            .toList(),
      );
    } catch (e) {
      return Left(e.toString());
    }
  }
}
