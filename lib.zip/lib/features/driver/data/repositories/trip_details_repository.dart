import 'package:snapix/core/models/trip_details_model.dart';
import 'package:snapix/core/services/supabase_service.dart';

class TripDetailsRepository {
  final _client = SupabaseService.client;

  static const _tripSelectQuery =
      '*, user:users!trips_user_id_fkey(id, name, phone, rating, avatar_url)';

  Future<TripDetailsModel> loadTripDetails(String tripId) async {
    final data = await _client
        .from('trips')
        .select(_tripSelectQuery)
        .eq('id', tripId)
        .single();
    return TripDetailsModel.fromJson(Map<String, dynamic>.from(data));
  }

  Future<Map<String, dynamic>?> acceptTrip(String tripId) async {
    final response = await _client.rpc(
      'driver_accept_trip',
      params: {'p_trip_id': tripId},
    );
    if (response == null) return {'success': true};
    if (response is Map) return Map<String, dynamic>.from(response);
    return null;
  }

  Future<void> rejectTripOffer({
    required String tripId,
    required String driverId,
  }) async {
    await _client.rpc(
      'driver_reject_trip',
      params: {'p_trip_id': tripId},
    );
  }

  Future<Map<String, dynamic>?> startTrip({
    required String tripId,
    required String driverId,
  }) async {
    final response = await _client.rpc(
      'driver_start_trip',
      params: {'p_trip_id': tripId, 'p_driver_id': driverId},
    );
    if (response == null) return {'success': true};
    if (response is Map) return Map<String, dynamic>.from(response);
    return null;
  }

  Future<Map<String, dynamic>?> completeTrip({
    required String tripId,
    required String driverId,
  }) async {
    final response = await _client.rpc(
      'driver_complete_trip',
      params: {'p_trip_id': tripId, 'p_driver_id': driverId},
    );
    if (response == null) return {'success': true};
    if (response is Map) return Map<String, dynamic>.from(response);
    return null;
  }

  Future<void> cancelTrip({
    required String tripId,
    required String driverId,
    String? cancelReason,
  }) async {
    await _client.rpc(
      'cancel_trip',
      params: {
        'p_trip_id': tripId,
        'p_user_id': driverId,
        'p_cancelled_by': 'driver',
        if (cancelReason != null) 'p_cancel_reason': cancelReason,
      },
    );
  }
}
