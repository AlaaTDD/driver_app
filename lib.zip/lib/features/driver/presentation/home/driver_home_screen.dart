import 'dart:async';
import 'package:snapix/core/localization/generated/app_localizations.dart';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geocoding/geocoding.dart';
import 'bloc/driver_home_bloc.dart';
import 'bloc/driver_home_event.dart';
import 'bloc/driver_home_state.dart';
import '../../../../core/constants/map_styles.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/theme_extensions.dart';
import '../../../../core/widgets/app_drawer.dart';
import '../../../../core/widgets/map_button.dart';
import '../../../../core/widgets/location_permission_cta.dart';
import '../../../../core/bloc/location_permission_cubit.dart';
import '../../../../core/constants/app_routes.dart';
import '../../../../features/auth/presentation/bloc/auth_bloc.dart';
import '../../../../features/auth/presentation/bloc/auth_event.dart';
import '../../../../features/auth/presentation/bloc/auth_state.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../services/supabase_service.dart';
import '../../../../services/heatmap_service.dart';
import '../../../../core/widgets/custom_animated_bottom_nav.dart';
import '../../../../services/directions_service.dart';
import '../../../../core/constants/env_constants.dart';
import '../widgets/driver_offer_overlay.dart';
import '../../../../core/utils/map_camera_utils.dart';
import 'widgets/neon_route_polyline.dart';

class DriverHomeScreen extends StatefulWidget {
  const DriverHomeScreen({super.key});

  @override
  State<DriverHomeScreen> createState() => _DriverHomeScreenState();
}

class _DriverHomeScreenState extends State<DriverHomeScreen>
    with WidgetsBindingObserver, SingleTickerProviderStateMixin {
  static const _corridorNeonLoopDuration = Duration(milliseconds: 3200);
  static const _corridorNeonFrameInterval = Duration(milliseconds: 33);
  static const _corridorNeonCoreWidth = 5;
  static const _corridorNeonGlowWidth = 13;
  static const _corridorNeonHaloWidth = 22;

  GoogleMapController? _mapController;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  int _bottomNavIndex = -1;

  static CameraPosition get _defaultCamera => CameraPosition(
        target: AppConstants.defaultMapCenter,
        zoom: 15,
      );

  double? _lastAnimatedLat;
  double? _lastAnimatedLng;
  bool _initialized = false;

  // ── Corridor polyline drawn on home map ─────────────────────────────────────
  Set<Polyline> _corridorPolylines = {};
  Set<Marker> _corridorMarkers = {};
  List<LatLng> _corridorRoutePoints = [];
  late final AnimationController _corridorNeonCtrl;
  Duration _lastCorridorNeonFrame = Duration.zero;

  static const double _bottomSheetHeight = 236.0;
  static const double _mapButtonSize = 48.0;
  static const double _mapButtonRadius = 14.0;
  static const double _topBarHorizontalPadding = 18.0;
  static const double _topBarVerticalPadding = 14.0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _corridorNeonCtrl = AnimationController(
      vsync: this,
      duration: _corridorNeonLoopDuration,
    )..addListener(_onCorridorNeonFrame);
    context.read<LocationPermissionCubit>().check();
    // Load any saved corridor from DB and draw on map
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadCorridorFromDb());
  }

  Future<void> _loadCorridorFromDb() async {
    try {
      final uid = SupabaseService.currentUser?.id;
      if (uid == null) return;
      final row = await SupabaseService.client
          .from('drivers_profile')
          .select(
              'target_origin_lat, target_origin_lng, target_dest_lat, target_dest_lng')
          .eq('id', uid)
          .maybeSingle();
      if (row == null) return;
      final oLat = (row['target_origin_lat'] as num?)?.toDouble();
      final oLng = (row['target_origin_lng'] as num?)?.toDouble();
      final dLat = (row['target_dest_lat'] as num?)?.toDouble();
      final dLng = (row['target_dest_lng'] as num?)?.toDouble();
      if (oLat != null && oLng != null && dLat != null && dLng != null) {
        _drawCorridorPolyline(LatLng(oLat, oLng), LatLng(dLat, dLng));
      }
    } catch (e) {
      debugPrint('⚠️ DriverHome: loadCorridor failed: $e');
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    if (!_initialized) {
      _initialized = true;
      context.read<DriverHomeBloc>().add(LoadDriverStatus());
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);

    _corridorNeonCtrl.dispose();
    _mapController?.dispose();
    _mapController = null;
    super.dispose();
  }

  void _onCorridorNeonFrame() {
    if (_corridorRoutePoints.length < 2) return;
    final elapsed = _corridorNeonCtrl.lastElapsedDuration ?? Duration.zero;
    if (elapsed - _lastCorridorNeonFrame < _corridorNeonFrameInterval) return;
    _lastCorridorNeonFrame = elapsed;
    if (!mounted) return;
    setState(() => _corridorPolylines = _buildCorridorNeonPolylines());
  }

  void _restartCorridorNeonLoop() {
    if (_corridorRoutePoints.length < 2) {
      _stopCorridorNeonLoop();
      return;
    }
    _lastCorridorNeonFrame = Duration.zero;
    _corridorNeonCtrl
      ..stop()
      ..reset()
      ..repeat();
  }

  void _stopCorridorNeonLoop() {
    _corridorNeonCtrl
      ..stop()
      ..reset();
    _lastCorridorNeonFrame = Duration.zero;
  }

  Set<Polyline> _buildCorridorNeonPolylines() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final routeColor =
        isDark ? const Color(0xFF34E7FF) : const Color(0xFF4169FF);
    return NeonRoutePolyline.build(
      points: _corridorRoutePoints,
      progress: NeonRoutePolyline.drawProgress(_corridorNeonCtrl.value),
      opacity: NeonRoutePolyline.fadeOpacity(_corridorNeonCtrl.value),
      color: routeColor,
      idPrefix: 'driver_corridor_neon',
      coreWidth: _corridorNeonCoreWidth,
      glowWidth: _corridorNeonGlowWidth,
      haloWidth: _corridorNeonHaloWidth,
    );
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      // Re-check location permission when returning from Settings
      context.read<LocationPermissionCubit>().recheck();

      final bloc = context.read<DriverHomeBloc>();
      if (bloc.state.isAvailable) {
        bloc.add(RefreshDriverLocation());
      }
    }
  }

  Future<void> _animateTo(double lat, double lng) async {
    if (_mapController == null) return;

    if (_lastAnimatedLat == lat && _lastAnimatedLng == lng) return;
    _lastAnimatedLat = lat;
    _lastAnimatedLng = lng;
    try {
      await _mapController!.animateCamera(
        CameraUpdate.newCameraPosition(
          CameraPosition(target: LatLng(lat, lng), zoom: 15),
        ),
      );
    } catch (e) {
      debugPrint('⚠️ DriverHome: animateCamera failed: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<DriverHomeBloc, DriverHomeState>(
      listenWhen: (prev, curr) =>
          (prev.driverLat != curr.driverLat ||
              prev.driverLng != curr.driverLng) &&
          curr.driverLat != null &&
          curr.driverLng != null,
      listener: (context, state) {
        if (state.driverLat != null && state.driverLng != null) {
          _animateTo(state.driverLat!, state.driverLng!);
        }
      },
      child: MultiBlocListener(
        listeners: [
          BlocListener<DriverHomeBloc, DriverHomeState>(
            listenWhen: (prev, curr) =>
                prev.acceptedTripId != curr.acceptedTripId &&
                curr.acceptedTripId != null,
            listener: (context, state) {
              if (state.acceptedTripId != null) {
                context.push(
                  '${AppRoutes.driverTripDetails}?tripId=${state.acceptedTripId}',
                );
              }
            },
          ),
          BlocListener<DriverHomeBloc, DriverHomeState>(
            listenWhen: (prev, curr) =>
                prev.errorMessage != curr.errorMessage &&
                curr.errorMessage != null,
            listener: (context, state) {
              if (state.errorMessage != null &&
                  state.errorMessage!.isNotEmpty) {
                final l = AppLocalizations.of(context)!;
                final msg = switch (state.errorMessage) {
                  'errorCannotGoOnlineDuringTrip' =>
                    l.errorCannotGoOnlineDuringTrip,
                  'errorUnexpected' => l.errorUnexpected,
                  _ => state.errorMessage!,
                };
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(msg),
                    backgroundColor: AppColors.error,
                  ),
                );
              }
            },
          ),
        ],
        child: DriverOfferOverlay(
          child: Scaffold(
            key: _scaffoldKey,
            extendBody: true,
            backgroundColor: context.bgColor,
            drawer: _buildDrawer(context),
            body: Stack(
              children: [
                _buildMap(),
                _buildTopBar(),
                _buildLocationButton(),
              ],
            ),
            bottomNavigationBar: _buildBottomNav(),
          ),
        ),
      ),
    );
  }

  Widget _buildMap() {
    return BlocBuilder<DriverHomeBloc, DriverHomeState>(
      buildWhen: (prev, curr) =>
          prev.driverLat != curr.driverLat ||
          prev.isAvailable != curr.isAvailable ||
          prev.heatmapCells != curr.heatmapCells,
      builder: (context, state) {
        final markers = <Marker>{..._corridorMarkers};
        final hexagons = _buildHeatmapHexagons(state.heatmapCells);
        final initialCamera =
            (state.driverLat != null && state.driverLng != null)
                ? CameraPosition(
                    target: LatLng(state.driverLat!, state.driverLng!),
                    zoom: 15)
                : _defaultCamera;

        return GoogleMap(
          initialCameraPosition: initialCamera,
          onMapCreated: (ctrl) {
            _mapController = ctrl;
            _lastAnimatedLat = null;
            _lastAnimatedLng = null;
            final s = context.read<DriverHomeBloc>().state;
            if (s.driverLat != null && s.driverLng != null) {
              Future.microtask(() => _animateTo(s.driverLat!, s.driverLng!));
            }
          },
          myLocationEnabled: true,
          myLocationButtonEnabled: false,
          zoomControlsEnabled: false,
          markers: markers,
          polygons: hexagons,
          polylines: _corridorPolylines, // ✅ corridor drawn here
          padding: const EdgeInsets.only(bottom: 24, top: 100),
          style: Theme.of(context).brightness == Brightness.dark
              ? kDarkMapStyle
              : kLightMapStyle,
        );
      },
    );
  }

  static const double _hexRadiusMeters = 300.0;

  Set<Polygon> _buildHeatmapHexagons(List<HeatmapCell> cells) {
    return cells.map((cell) {
      Color fillColor;
      Color strokeColor;

      switch (cell.level) {
        case HeatmapLevel.high:
          fillColor = AppColors.error.withValues(alpha: 0.35);
          strokeColor = AppColors.error.withValues(alpha: 0.60);
          break;
        case HeatmapLevel.medium:
          fillColor = AppColors.warning.withValues(alpha: 0.25);
          strokeColor = AppColors.warning.withValues(alpha: 0.50);
          break;
        case HeatmapLevel.low:
          fillColor = AppColors.warningLight.withValues(alpha: 0.16);
          strokeColor = AppColors.warningLight.withValues(alpha: 0.35);
          break;
      }

      final vertices = _hexagonVertices(
        cell.centerLat,
        cell.centerLng,
        _hexRadiusMeters,
      );

      return Polygon(
        polygonId: PolygonId('hex_${cell.cellId}'),
        points: vertices,
        fillColor: fillColor,
        strokeColor: strokeColor,
        strokeWidth: 1,
      );
    }).toSet();
  }

  static final List<double> _hexSin = [
    math.sin(0 * math.pi / 180.0),
    math.sin(60 * math.pi / 180.0),
    math.sin(120 * math.pi / 180.0),
    math.sin(180 * math.pi / 180.0),
    math.sin(240 * math.pi / 180.0),
    math.sin(300 * math.pi / 180.0),
  ];
  static final List<double> _hexCos = [
    math.cos(0 * math.pi / 180.0),
    math.cos(60 * math.pi / 180.0),
    math.cos(120 * math.pi / 180.0),
    math.cos(180 * math.pi / 180.0),
    math.cos(240 * math.pi / 180.0),
    math.cos(300 * math.pi / 180.0),
  ];

  List<LatLng> _hexagonVertices(double lat, double lng, double radiusMeters) {
    final latPerMeter = 1.0 / 111320.0;
    final lngPerMeter = 1.0 / (111320.0 * math.cos(lat * math.pi / 180.0));

    final vertices = <LatLng>[];
    for (int i = 0; i < 6; i++) {
      final dLat = radiusMeters * _hexSin[i] * latPerMeter;
      final dLng = radiusMeters * _hexCos[i] * lngPerMeter;
      vertices.add(LatLng(lat + dLat, lng + dLng));
    }
    return vertices;
  }

  Widget _buildTopBar() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: _topBarHorizontalPadding,
          vertical: _topBarVerticalPadding,
        ),
        child: Row(
          children: [
            MapButton(
              icon: Icons.menu_rounded,
              size: _mapButtonSize,
              borderRadius: _mapButtonRadius,
              onTap: () => _scaffoldKey.currentState?.openDrawer(),
            ),
            const Spacer(),
            BlocBuilder<DriverHomeBloc, DriverHomeState>(
              builder: (context, state) {
                return GestureDetector(
                  onTap: () => context.push(AppRoutes.driverWallet),
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: context.elevatedColor,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? AppColors.white.withValues(alpha: 0.08)
                              : AppColors.black.withValues(alpha: 0.1),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.account_balance_wallet_rounded,
                            color: AppColors.primary, size: 20),
                        const SizedBox(width: 8),
                        Text(
                          AppLocalizations.of(context)!.priceWithCurrency(
                              state.availableBalance.toStringAsFixed(0),
                              AppLocalizations.of(context)!.currencySar),
                          style: TextStyle(
                            color: context.textPrimary,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(width: 4),
                        Icon(Icons.chevron_right_rounded,
                            color: context.textSecondary, size: 16),
                      ],
                    ),
                  ),
                );
              },
            ),
            const Spacer(),
            MapButton(
              icon: Icons.notifications_outlined,
              size: _mapButtonSize,
              borderRadius: _mapButtonRadius,
              onTap: () => context.push(AppRoutes.driverNotifications),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLocationButton() {
    return Positioned(
      bottom: 120,
      right: 18,
      child: MapButton(
        icon: Icons.my_location_rounded,
        size: _mapButtonSize,
        borderRadius: _mapButtonRadius,
        onTap: () {
          final s = context.read<DriverHomeBloc>().state;
          if (s.driverLat != null && s.driverLng != null) {
            _lastAnimatedLat = null;
            _lastAnimatedLng = null;
            _animateTo(s.driverLat!, s.driverLng!);
          }
        },
      ),
    );
  }

  Widget _buildBottomNav() {
    final l = AppLocalizations.of(context)!;
    return CustomAnimatedBottomNav(
      items: [
        BottomNavItem(
          icon: Icons.list_alt_outlined,
          activeIcon: Icons.list_alt_rounded,
          label: l.trips,
        ),
        BottomNavItem(
          icon: Icons.alt_route_outlined,
          activeIcon: Icons.alt_route_rounded,
          label: l.destination,
        ),
      ],
      onTap: (index) {
        if (index == 0) {
          context.push(AppRoutes.driverRequestFeed); // ✅ real-time request feed
        } else if (index == 1) {
          _showCorridorPicker(context);
        }
      },
      itemColor: context.textSecondary,
      backgroundColor: context.cardColor,
      notchColor: AppColors.transparent,
      notchRadius: 42,
      gapWidth: 90,
      floatingActionButton: _buildGoButtonInner(),
    );
  }

  void _showCorridorPicker(BuildContext context) {
    final bloc = context.read<DriverHomeBloc>();
    final lat = bloc.state.driverLat ?? AppConstants.defaultMapCenter.latitude;
    final lng = bloc.state.driverLng ?? AppConstants.defaultMapCenter.longitude;
    Navigator.push<Map<String, LatLng>>(
      context,
      MaterialPageRoute(
        fullscreenDialog: true,
        builder: (_) => _CorridorPickerScreen(
          initialCenter: LatLng(lat, lng),
        ),
      ),
    ).then((result) {
      if (result == null) return;
      if (result.containsKey('cleared')) {
        // User cleared the corridor
        _stopCorridorNeonLoop();
        if (mounted)
          setState(() {
            _corridorRoutePoints = [];
            _corridorPolylines = {};
            _corridorMarkers = {};
          });
        return;
      }
      final origin = result['origin']!;
      final dest = result['dest']!;
      _drawCorridorPolyline(origin, dest);
    });
  }

  Future<void> _drawCorridorPolyline(LatLng origin, LatLng dest) async {
    if (!mounted) return;
    final l = AppLocalizations.of(context)!;

    // Show markers immediately
    _stopCorridorNeonLoop();
    setState(() {
      _corridorRoutePoints = [];
      _corridorPolylines = {};
      _corridorMarkers = {
        Marker(
          markerId: const MarkerId('corr_origin'),
          position: origin,
          icon:
              BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
          infoWindow: InfoWindow(title: l.corridorStart),
        ),
        Marker(
          markerId: const MarkerId('corr_dest'),
          position: dest,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
          infoWindow: InfoWindow(title: l.corridorEnd),
        ),
      };
    });

    // Fetch real route
    final result = await DirectionsService.getRoute(
      originLat: origin.latitude,
      originLng: origin.longitude,
      destLat: dest.latitude,
      destLng: dest.longitude,
      apiKey: EnvConstants.googleMapsApiKey,
    );

    if (!mounted || result == null || result.points.isEmpty) return;

    final points = result.points;

    setState(() {
      _corridorRoutePoints = points;
      _corridorPolylines = _buildCorridorNeonPolylines();
    });
    _restartCorridorNeonLoop();

    // Fit camera to polyline
    if (_mapController != null) {
      await MapCameraUtils.fitCameraToPoints(
        _mapController!,
        points,
        padding: 92,
        delay: const Duration(milliseconds: 300),
      );
    }
  }

  Widget _buildGoButtonInner() {
    return BlocBuilder<LocationPermissionCubit, LocationPermissionState>(
      builder: (context, permState) {
        // ── Location blocked → show CTA button instead of GO ──
        if (permState.isBlocked) {
          return LocationPermissionCta(
            variant: LocationCtaVariant.button,
            onGranted: () {
              // Re-load driver status when permission is granted
              context.read<DriverHomeBloc>().add(LoadDriverStatus());
            },
          );
        }

        // ── Normal GO button ──
        return BlocBuilder<DriverHomeBloc, DriverHomeState>(
          builder: (context, state) {
            final isOnline = state.isAvailable;
            final isLoading = state.isLoading;

            return GestureDetector(
              onTap: isLoading
                  ? null
                  : () {
                      context
                          .read<DriverHomeBloc>()
                          .add(ToggleAvailability(!isOnline));
                    },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 350),
                curve: Curves.fastOutSlowIn,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: isOnline
                        ? [
                            AppColors.success,
                            AppColors.success,
                          ]
                        : [
                            AppColors.error,
                            AppColors.error,
                          ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  border: Border.all(
                    color: AppColors.white.withValues(alpha: 0.25),
                    width: 3,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: (isOnline ? AppColors.success : AppColors.error)
                          .withValues(alpha: 0.5),
                      blurRadius: isOnline ? 25 : 15,
                      spreadRadius: isOnline ? 8 : 2,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: Center(
                  child: isLoading
                      ? const CircularProgressIndicator(
                          color: AppColors.white, strokeWidth: 3)
                      : Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              isOnline
                                  ? Icons.sensors_rounded
                                  : Icons.power_settings_new_rounded,
                              color: AppColors.white,
                              size: 26,
                            ),
                            const SizedBox(height: 2),
                            Text(
                              isOnline
                                  ? AppLocalizations.of(context)!.onlineStatus
                                  : AppLocalizations.of(context)!.offlineStatus,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                color: AppColors.white,
                                fontWeight: FontWeight.w900,
                                fontSize: 12.5,
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildDrawer(BuildContext context) {
    final authState = context.read<AuthBloc>().state;
    final user = authState is AuthAuthenticated ? authState.user : null;
    return AppDrawer(
      user: user,
      onProfileTap: () {
        Navigator.pop(context);
        context.push(AppRoutes.driverProfile);
      },
      onWalletTap: () {
        Navigator.pop(context);
        context.push(AppRoutes.driverWallet);
      },
      onTripsTap: () {
        Navigator.pop(context);
        context.push(AppRoutes.driverTrips);
      },
      onMessagesTap: () {
        Navigator.pop(context);
        context.push(AppRoutes.driverMessages);
      },
      onChatbotTap: () {
        Navigator.pop(context);
        context.push(AppRoutes.driverChatbot);
      },
      onComplaintsTap: () {
        Navigator.pop(context);
        context.push(AppRoutes.driverComplaints);
      },
      onRevisionTap: () {
        Navigator.pop(context);
        context.push(AppRoutes.driverRevision);
      },
      onLogout: () {
        Navigator.pop(context);
        context.read<DriverHomeBloc>().add(ResetDriverStatus());
        context.read<AuthBloc>().add(SignOutRequested());
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  CORRIDOR PICKER SCREEN  — two-tap free selection
// ═══════════════════════════════════════════════════════════════════════════

class _CorridorPickerScreen extends StatefulWidget {
  final LatLng initialCenter;
  const _CorridorPickerScreen({required this.initialCenter});

  @override
  State<_CorridorPickerScreen> createState() => _CorridorPickerScreenState();
}

enum _CorridorPointTarget { origin, destination }

class _CorridorPickerScreenState extends State<_CorridorPickerScreen>
    with SingleTickerProviderStateMixin {
  static const _neonLoopDuration = Duration(milliseconds: 3200);
  static const _neonFrameInterval = Duration(milliseconds: 33);
  static const _neonCoreWidth = 5;
  static const _neonGlowWidth = 13;
  static const _neonHaloWidth = 22;

  // Tap step: 0 = waiting for origin, 1 = waiting for dest, 2 = done
  int _step = 0;

  GoogleMapController? _mapCtrl;
  final TextEditingController _searchCtrl = TextEditingController();

  LatLng? _originPt;
  LatLng? _destPt;
  String? _originAddr;
  String? _destAddr;
  _CorridorPointTarget _pickTarget = _CorridorPointTarget.origin;
  double _originRadiusKm = 2.0;
  double _destRadiusKm = 3.0;
  bool _isResolving = false;
  bool _isSaving = false;

  List<LatLng> _routePoints = [];
  late final AnimationController _neonRouteCtrl;
  Duration _lastNeonFrame = Duration.zero;

  @override
  void initState() {
    super.initState();
    _neonRouteCtrl = AnimationController(
      vsync: this,
      duration: _neonLoopDuration,
    )..addListener(_onNeonRouteFrame);
    _loadExistingCorridor();
  }

  @override
  void dispose() {
    _neonRouteCtrl.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  void _onNeonRouteFrame() {
    if (_routePoints.length < 2) return;
    final elapsed = _neonRouteCtrl.lastElapsedDuration ?? Duration.zero;
    if (elapsed - _lastNeonFrame < _neonFrameInterval) return;
    _lastNeonFrame = elapsed;
    if (mounted) setState(() {});
  }

  void _restartNeonRouteLoop() {
    if (_routePoints.length < 2) {
      _stopNeonRouteLoop();
      return;
    }
    _lastNeonFrame = Duration.zero;
    _neonRouteCtrl
      ..stop()
      ..reset()
      ..repeat();
  }

  void _stopNeonRouteLoop() {
    _neonRouteCtrl
      ..stop()
      ..reset();
    _lastNeonFrame = Duration.zero;
  }

  void _clearRoutePreview() {
    _stopNeonRouteLoop();
    _routePoints = [];
  }

  Future<void> _loadExistingCorridor() async {
    setState(() => _isResolving = true);
    try {
      final uid = SupabaseService.currentUser?.id;
      if (uid != null) {
        final row = await SupabaseService.client
            .from('drivers_profile')
            .select(
                'target_origin_lat, target_origin_lng, target_dest_lat, target_dest_lng, target_origin_radius_km, target_route_radius_km')
            .eq('id', uid)
            .maybeSingle();

        if (row != null) {
          final oLat = (row['target_origin_lat'] as num?)?.toDouble();
          final oLng = (row['target_origin_lng'] as num?)?.toDouble();
          final dLat = (row['target_dest_lat'] as num?)?.toDouble();
          final dLng = (row['target_dest_lng'] as num?)?.toDouble();

          if (oLat != null && oLng != null && dLat != null && dLng != null) {
            _originPt = LatLng(oLat, oLng);
            _destPt = LatLng(dLat, dLng);
            _originRadiusKm =
                (row['target_origin_radius_km'] as num?)?.toDouble() ?? 2.0;
            _destRadiusKm =
                (row['target_route_radius_km'] as num?)?.toDouble() ?? 3.0;
            _step = 2; // both points set
            _pickTarget = _CorridorPointTarget.origin;

            // try to get addresses
            try {
              final oMarks = await placemarkFromCoordinates(oLat, oLng);
              if (oMarks.isNotEmpty)
                _originAddr =
                    '${oMarks.first.street ?? ''}, ${oMarks.first.locality ?? ''}';
              final dMarks = await placemarkFromCoordinates(dLat, dLng);
              if (dMarks.isNotEmpty)
                _destAddr =
                    '${dMarks.first.street ?? ''}, ${dMarks.first.locality ?? ''}';
            } catch (e, st) {
              debugPrint(
                  '⚠️ DriverHomeScreen: failed to reverse geocode corridor: $e\n$st');
            }

            _fetchAndDrawRoute();
          }
        }
      }
    } catch (e) {
      debugPrint('Error loading corridor: $e');
    } finally {
      if (mounted) setState(() => _isResolving = false);
    }
  }

  Future<void> _searchLocation(String query) async {
    if (query.trim().isEmpty) return;
    setState(() => _isResolving = true);
    try {
      final locs = await locationFromAddress(query);
      if (locs.isNotEmpty) {
        final ll = LatLng(locs.first.latitude, locs.first.longitude);
        _mapCtrl?.animateCamera(CameraUpdate.newLatLngZoom(ll, 14));
      }
    } catch (e) {
      if (mounted) {
        final l = AppLocalizations.of(context)!;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text(l.errorLocationNotFound),
              backgroundColor: AppColors.error),
        );
      }
    } finally {
      if (mounted) setState(() => _isResolving = false);
    }
  }

  Future<void> _onMapTap(LatLng ll) async {
    if (_isSaving) return;
    final target = _pickTarget;
    setState(() => _isResolving = true);

    String? address;
    try {
      final placemarks =
          await placemarkFromCoordinates(ll.latitude, ll.longitude);
      if (placemarks.isNotEmpty) {
        final p = placemarks.first;
        address = '${p.street ?? ''}, ${p.locality ?? ''}';
      }
    } catch (e, st) {
      debugPrint(
          '⚠️ DriverHomeScreen: failed to reverse geocode map tap: $e\n$st');
      address =
          '${ll.latitude.toStringAsFixed(4)}, ${ll.longitude.toStringAsFixed(4)}';
    }

    var shouldFetchRoute = false;
    setState(() {
      _clearRoutePreview();
      if (target == _CorridorPointTarget.origin) {
        _originPt = ll;
        _originAddr = address;
        if (_destPt != null) {
          _step = 2;
          shouldFetchRoute = true;
        } else {
          _step = 1;
          _pickTarget = _CorridorPointTarget.destination;
        }
      } else {
        _destPt = ll;
        _destAddr = address;
        if (_originPt != null) {
          _step = 2;
          shouldFetchRoute = true;
        } else {
          _step = 0;
          _pickTarget = _CorridorPointTarget.origin;
        }
      }
      _isResolving = false;
    });
    if (shouldFetchRoute) await _fetchAndDrawRoute();
  }

  Future<void> _fetchAndDrawRoute() async {
    if (_originPt == null || _destPt == null) return;
    final result = await DirectionsService.getRoute(
      originLat: _originPt!.latitude,
      originLng: _originPt!.longitude,
      destLat: _destPt!.latitude,
      destLng: _destPt!.longitude,
      apiKey: EnvConstants.googleMapsApiKey,
    );
    if (!mounted || result == null) return;
    setState(() {
      _routePoints = result.points;
    });
    _restartNeonRouteLoop();

    final ctrl = _mapCtrl;
    if (ctrl != null) {
      await MapCameraUtils.fitCameraToPoints(
        ctrl,
        _routePoints,
        padding: 92,
        delay: const Duration(milliseconds: 120),
      );
    }
  }

  void _reset() {
    _stopNeonRouteLoop();
    setState(() {
      _step = 0;
      _pickTarget = _CorridorPointTarget.origin;
      _originPt = null;
      _destPt = null;
      _originAddr = null;
      _destAddr = null;
      _routePoints = [];
    });
  }

  void _onOriginChipTap() {
    setState(() {
      if (_originPt != null) {
        _originPt = null;
        _originAddr = null;
        _clearRoutePreview();
      }
      _pickTarget = _CorridorPointTarget.origin;
      _step = _originPt != null && _destPt != null
          ? 2
          : _originPt != null
              ? 1
              : 0;
    });
  }

  void _onDestinationChipTap() {
    setState(() {
      if (_destPt != null) {
        _destPt = null;
        _destAddr = null;
        _clearRoutePreview();
      }
      _pickTarget = _CorridorPointTarget.destination;
      _step = _originPt != null && _destPt != null ? 2 : 1;
    });
  }

  Future<void> _save() async {
    if (_originPt == null || _destPt == null) return;
    setState(() => _isSaving = true);
    try {
      // Use the dedicated RPC so server-side validation runs correctly
      await SupabaseService.client.rpc('set_driver_target_route', params: {
        'p_driver_id': SupabaseService.currentUser!.id,
        'p_origin_lat': _originPt!.latitude,
        'p_origin_lng': _originPt!.longitude,
        'p_dest_lat': _destPt!.latitude,
        'p_dest_lng': _destPt!.longitude,
        'p_origin_radius_km': _originRadiusKm,
        'p_dest_radius_km': _destRadiusKm,
      });

      if (mounted) {
        Navigator.pop<Map<String, LatLng>>(context, {
          'origin': _originPt!,
          'dest': _destPt!,
        });
      }
    } catch (e) {
      // Fallback: direct write if RPC not found / signature changed
      try {
        await SupabaseService.client.from('drivers_profile').update({
          'target_origin_lat': _originPt!.latitude,
          'target_origin_lng': _originPt!.longitude,
          'target_dest_lat': _destPt!.latitude,
          'target_dest_lng': _destPt!.longitude,
          'target_origin_radius_km': _originRadiusKm,
          'target_route_radius_km': _destRadiusKm,
        }).eq('id', SupabaseService.currentUser!.id);
        if (mounted) {
          Navigator.pop<Map<String, LatLng>>(context, {
            'origin': _originPt!,
            'dest': _destPt!,
          });
        }
      } catch (e2) {
        if (mounted) {
          final l = AppLocalizations.of(context)!;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
                content: Text(l.errorWithDetails(e2.toString())),
                backgroundColor: AppColors.error),
          );
        }
      }
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  Future<void> _clear() async {
    try {
      _stopNeonRouteLoop();
      await SupabaseService.client.from('drivers_profile').update({
        'target_origin_lat': null,
        'target_origin_lng': null,
        'target_dest_lat': null,
        'target_dest_lng': null,
      }).eq('id', SupabaseService.currentUser!.id);

      if (mounted) {
        Navigator.pop<Map<String, LatLng>>(context, {'cleared': LatLng(0, 0)});
      }
    } catch (e) {
      debugPrint('CorridorPicker: clear failed $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context)!;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final panelColor = context.bgColor;
    final neonRouteColor =
        isDark ? const Color(0xFF34E7FF) : const Color(0xFF4169FF);
    final neonRouteProgress = NeonRoutePolyline.drawProgress(
      _neonRouteCtrl.value,
    );
    final neonRouteOpacity = NeonRoutePolyline.fadeOpacity(
      _neonRouteCtrl.value,
    );

    final hasBothPoints = _originPt != null && _destPt != null;
    final String hintText = hasBothPoints
        ? l.corridorReviewHint
        : _pickTarget == _CorridorPointTarget.destination
            ? l.corridorPickDestinationHint
            : l.corridorPickOriginHint;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: AppColors.transparent,
        elevation: 0,
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            margin: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: panelColor.withValues(alpha: 0.9),
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                    color: AppColors.black.withValues(alpha: 0.26),
                    blurRadius: 8)
              ],
            ),
            child: Icon(Icons.arrow_back_ios_new_rounded,
                size: 17,
                color: isDark
                    ? AppColors.white.withValues(alpha: 0.7)
                    : AppColors.black.withValues(alpha: 0.87)),
          ),
        ),
      ),
      body: Stack(children: [
        // ── Map ──────────────────────────────────────────────────────────────
        GoogleMap(
          initialCameraPosition:
              CameraPosition(target: widget.initialCenter, zoom: 13),
          onMapCreated: (ctrl) => _mapCtrl = ctrl,
          onTap: _onMapTap,
          style: isDark ? kDarkMapStyle : kLightMapStyle,
          myLocationEnabled: true,
          myLocationButtonEnabled: false,
          zoomControlsEnabled: false,
          mapToolbarEnabled: false,
          circles: {
            if (_originPt != null)
              Circle(
                circleId: const CircleId('origin_zone'),
                center: _originPt!,
                radius: _originRadiusKm * 1000,
                fillColor: AppColors.success.withValues(alpha: 0.12),
                strokeColor: AppColors.success.withValues(alpha: 0.8),
                strokeWidth: 2,
              ),
            if (_destPt != null)
              Circle(
                circleId: const CircleId('dest_zone'),
                center: _destPt!,
                radius: _destRadiusKm * 1000,
                fillColor: AppColors.primary.withValues(alpha: 0.12),
                strokeColor: AppColors.primary.withValues(alpha: 0.8),
                strokeWidth: 2,
              ),
          },
          polylines: _routePoints.isNotEmpty
              ? NeonRoutePolyline.build(
                  points: _routePoints,
                  progress: neonRouteProgress,
                  opacity: neonRouteOpacity,
                  color: neonRouteColor,
                  idPrefix: 'corridor_neon',
                  coreWidth: _neonCoreWidth,
                  glowWidth: _neonGlowWidth,
                  haloWidth: _neonHaloWidth,
                )
              : (_originPt != null && _destPt != null)
                  ? {
                      Polyline(
                        polylineId: const PolylineId('corridor_straight'),
                        points: [_originPt!, _destPt!],
                        color: AppColors.primary.withValues(alpha: 0.5),
                        width: 3,
                        patterns: [PatternItem.dash(20), PatternItem.gap(10)],
                      ),
                    }
                  : {},
          markers: {
            if (_originPt != null)
              Marker(
                markerId: const MarkerId('origin'),
                position: _originPt!,
                anchor: const Offset(0.5, 0.5),
                icon: BitmapDescriptor.defaultMarkerWithHue(
                    BitmapDescriptor.hueGreen),
                infoWindow:
                    InfoWindow(title: l.corridorStart, snippet: _originAddr),
              ),
            if (_destPt != null)
              Marker(
                markerId: const MarkerId('dest'),
                position: _destPt!,
                anchor: const Offset(0.5, 0.5),
                icon: BitmapDescriptor.defaultMarkerWithHue(
                    BitmapDescriptor.hueBlue),
                infoWindow:
                    InfoWindow(title: l.corridorEnd, snippet: _destAddr),
              ),
          },
        ),

        // ── Search Bar ──────────────────────────────────────────────────────
        Positioned(
          top: MediaQuery.of(context).padding.top + 60,
          left: 16,
          right: 16,
          child: Container(
            decoration: BoxDecoration(
              color: panelColor.withValues(alpha: 0.95),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                    color: AppColors.black.withValues(alpha: 0.26),
                    blurRadius: 10)
              ],
            ),
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(children: [
              const Icon(Icons.search_rounded, color: AppColors.grey, size: 20),
              const SizedBox(width: 10),
              Expanded(
                child: TextField(
                  controller: _searchCtrl,
                  decoration: InputDecoration(
                    hintText: l.corridorSearchHint,
                    hintStyle:
                        const TextStyle(fontSize: 13, color: AppColors.grey),
                    border: InputBorder.none,
                  ),
                  style: TextStyle(
                      fontSize: 13,
                      color: context.textPrimary),
                  onSubmitted: _searchLocation,
                ),
              ),
              if (_isResolving)
                const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2)),
            ]),
          ),
        ),

        // ── Step hint banner ────────────────────────────────────────────────
        if (!_isResolving)
          PositionedDirectional(
            top: MediaQuery.of(context).padding.top + 8,
            start: 66,
            end: 16,
            child: _CorridorHintPill(hint: hintText),
          ),

        if (_isResolving)
          PositionedDirectional(
            top: MediaQuery.of(context).padding.top + 8,
            start: 66,
            end: 16,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: AppColors.black.withValues(alpha: 0.75),
                borderRadius: BorderRadius.circular(24),
              ),
              child:
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                        color: AppColors.white, strokeWidth: 2)),
                const SizedBox(width: 10),
                Text(l.processing,
                    style:
                        const TextStyle(color: AppColors.white, fontSize: 13)),
              ]),
            ),
          ),

        // ── Bottom panel ────────────────────────────────────────────────────
        Positioned(
          bottom: 0,
          left: 0,
          right: 0,
          child: Container(
            decoration: BoxDecoration(
              color: panelColor,
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(28)),
              boxShadow: [
                BoxShadow(
                    color: AppColors.black.withValues(alpha: 0.38),
                    blurRadius: 20,
                    offset: Offset(0, -4))
              ],
            ),
            padding: EdgeInsets.fromLTRB(
                20, 14, 20, MediaQuery.of(context).padding.bottom + 20),
            child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Center(
                      child: Container(
                          width: 36,
                          height: 4,
                          decoration: BoxDecoration(
                              color: AppColors.grey.withValues(alpha: 0.3),
                              borderRadius: BorderRadius.circular(100)))),
                  const SizedBox(height: 14),

                  // Origin + Dest chips
                  Row(children: [
                    _PointChip(
                      isDone: _originPt != null,
                      isActive: _pickTarget == _CorridorPointTarget.origin &&
                          _originPt == null,
                      color: AppColors.success,
                      icon: Icons.trip_origin_rounded,
                      label: l.pickupPoint,
                      address: _originAddr,
                      onTap: _onOriginChipTap,
                    ),
                    const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 6),
                      child: Icon(Icons.arrow_forward_rounded,
                          size: 16, color: AppColors.grey),
                    ),
                    _PointChip(
                      isDone: _destPt != null,
                      isActive:
                          _pickTarget == _CorridorPointTarget.destination &&
                              _destPt == null,
                      color: AppColors.primary,
                      icon: Icons.flag_rounded,
                      label: l.corridorEnd,
                      address: _destAddr,
                      onTap: _onDestinationChipTap,
                    ),
                  ]),

                  // Sliders — only visible when both points are set
                  if (_step == 2) ...[
                    const SizedBox(height: 16),
                    _RadiusSlider(
                      label: l.corridorOriginRadius,
                      color: AppColors.success,
                      value: _originRadiusKm,
                      min: 0.5,
                      max: 10.0,
                      onChanged: (v) => setState(() => _originRadiusKm = v),
                    ),
                    const SizedBox(height: 8),
                    _RadiusSlider(
                      label: l.corridorDestinationRadius,
                      color: AppColors.primary,
                      value: _destRadiusKm,
                      min: 0.5,
                      max: 15.0,
                      onChanged: (v) => setState(() => _destRadiusKm = v),
                    ),
                  ],

                  const SizedBox(height: 16),

                  SizedBox(
                    height: 50,
                    child: ElevatedButton.icon(
                      onPressed: (_step == 2 && !_isSaving && !_isResolving)
                          ? _save
                          : null,
                      icon: _isSaving
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: AppColors.white))
                          : const Icon(Icons.save_rounded),
                      label: Text(
                        _step == 0
                            ? l.selectOriginFirst
                            : _step == 1
                                ? l.selectDestination
                                : l.savePreferredCorridor,
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        foregroundColor: AppColors.white,
                        disabledBackgroundColor: AppColors.grey,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16)),
                        elevation: 0,
                        textStyle: const TextStyle(
                            fontSize: 14, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),

                  if (_originPt != null || _destPt != null) ...[
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: _CorridorPanelAction(
                            label: l.resetButton,
                            icon: Icons.refresh_rounded,
                            color: AppColors.warning,
                            onTap: _reset,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _CorridorPanelAction(
                            label: l.clearButton,
                            icon: Icons.delete_outline_rounded,
                            color: AppColors.error,
                            onTap: _clear,
                          ),
                        ),
                      ],
                    ),
                  ],
                ]),
          ),
        ),
      ]),
    );
  }
}

class _CorridorHintPill extends StatelessWidget {
  final String hint;

  const _CorridorHintPill({
    required this.hint,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 38),
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.black.withValues(alpha: 0.76),
        borderRadius: BorderRadius.circular(17),
        boxShadow: [
          BoxShadow(
            color: AppColors.black.withValues(alpha: 0.26),
            blurRadius: 10,
          ),
        ],
      ),
      child: Text(
        hint,
        textAlign: TextAlign.center,
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          color: AppColors.white.withValues(alpha: 0.90),
          fontSize: 12,
          fontWeight: FontWeight.w700,
          height: 1.25,
        ),
      ),
    );
  }
}

class _PointChip extends StatelessWidget {
  final bool isDone;
  final bool isActive;
  final Color color;
  final IconData icon;
  final String label;
  final String? address;
  final VoidCallback onTap;

  const _PointChip({
    required this.isDone,
    required this.isActive,
    required this.color,
    required this.icon,
    required this.label,
    required this.onTap,
    this.address,
  });

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context)!;
    return Expanded(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(
            color: isDone
                ? color.withValues(alpha: 0.12)
                : isActive
                    ? color.withValues(alpha: 0.08)
                    : AppColors.grey.withValues(alpha: 0.05),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: isDone || isActive
                  ? color.withValues(alpha: isDone ? 0.50 : 0.38)
                  : AppColors.grey.withValues(alpha: 0.2),
              width: isActive ? 1.4 : 1,
            ),
          ),
          child: Row(children: [
            Icon(icon,
                color: isDone || isActive ? color : AppColors.grey, size: 16),
            const SizedBox(width: 6),
            Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                  Text(label,
                      style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: isDone || isActive ? color : AppColors.grey)),
                  if (address != null)
                    Text(address!,
                        style:
                            const TextStyle(fontSize: 9, color: AppColors.grey),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis)
                  else
                    Text(isActive ? l.tapMap : l.noData,
                        style: const TextStyle(
                            fontSize: 9, color: AppColors.grey)),
                ])),
            if (isDone) ...[
              const SizedBox(width: 4),
              Icon(Icons.close_rounded,
                  size: 15, color: color.withValues(alpha: 0.85)),
            ],
          ]),
        ),
      ),
    );
  }
}

class _CorridorPanelAction extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _CorridorPanelAction({
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
        height: 40,
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.10),
          borderRadius: BorderRadius.circular(13),
          border: Border.all(color: color.withValues(alpha: 0.26)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 17),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RadiusSlider extends StatelessWidget {
  final String label;
  final Color color;
  final double value;
  final double min;
  final double max;
  final bool enabled;
  final ValueChanged<double> onChanged;

  const _RadiusSlider({
    required this.label,
    required this.color,
    required this.value,
    required this.min,
    required this.max,
    this.enabled = true,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context)!;
    return Row(children: [
      SizedBox(
        width: 110,
        child: Text(label,
            style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: enabled ? null : AppColors.grey)),
      ),
      Expanded(
        child: SliderTheme(
          data: SliderTheme.of(context).copyWith(
            activeTrackColor: enabled ? color : AppColors.grey,
            inactiveTrackColor: AppColors.grey.withValues(alpha: 0.2),
            thumbColor: enabled ? color : AppColors.grey,
            overlayColor: color.withValues(alpha: 0.1),
            trackHeight: 3,
            thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 8),
          ),
          child: Slider(
            value: value.clamp(min, max),
            min: min,
            max: max,
            divisions: ((max - min) / 0.5).round(),
            onChanged: enabled ? onChanged : null,
          ),
        ),
      ),
      SizedBox(
        width: 44,
        child: Text(l.kmValue(value.toStringAsFixed(1)),
            style: TextStyle(
                fontSize: 10,
                color: enabled ? color : AppColors.grey,
                fontWeight: FontWeight.w700),
            textAlign: TextAlign.end),
      ),
    ]);
  }
}

class _LegendChip extends StatelessWidget {
  final Color color;
  final String label;
  const _LegendChip({required this.color, required this.label});

  @override
  Widget build(BuildContext context) =>
      Row(mainAxisSize: MainAxisSize.min, children: [
        Container(
            width: 12,
            height: 12,
            decoration: BoxDecoration(
                color: color.withValues(alpha: 0.3),
                shape: BoxShape.circle,
                border: Border.all(color: color, width: 1.5))),
        const SizedBox(width: 6),
        Text(label,
            style: TextStyle(
                fontSize: 11, color: color, fontWeight: FontWeight.w600)),
      ]);
}
