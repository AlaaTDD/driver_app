import 'dart:async';
import 'supabase_service.dart';
import 'package:snapix/core/utils/app_logger.dart';

class HeatmapService {
  HeatmapService._();
  static final HeatmapService instance = HeatmapService._();

  static const double hexRadiusMeters = 300.0;
  static const Duration _refreshInterval = Duration(seconds: 10);

  Timer? _refreshTimer;
  bool _isDisposed = false;

  final _heatmapController = StreamController<List<HeatmapCell>>.broadcast();

  Stream<List<HeatmapCell>> get heatmapUpdates => _heatmapController.stream;

  List<HeatmapCell> _currentCells = [];

  List<HeatmapCell> get currentCells => List.unmodifiable(_currentCells);

  Future<void> startRealtimeUpdates() async {
    _isDisposed = false; // Allow restarting after sign-out

    if (_refreshTimer != null) {
      if (!_heatmapController.isClosed) {
        _heatmapController.add(List.unmodifiable(_currentCells));
      }
      AppLogger.debug(
          '🔥 Heatmap: Already connected — pushed ${_currentCells.length} cells to new subscriber');
      return;
    }

    await _fetchHeatmap();
    _refreshTimer ??= Timer.periodic(
      _refreshInterval,
      (_) => unawaited(_fetchHeatmap()),
    );
  }

  void stopRealtimeUpdates() {
    _refreshTimer?.cancel();
    _refreshTimer = null;
    _currentCells = [];
    if (!_heatmapController.isClosed) {
      _heatmapController.add([]);
    }
  }

  void dispose() {
    _isDisposed = true;
    stopRealtimeUpdates();
    // Do NOT close _heatmapController because this is a Singleton.
    // If user signs out and signs back in, the stream must still be open.
    if (!_heatmapController.isClosed) {
      _heatmapController.add([]); // Emit empty to clear map
    }
  }

  Future<void> _fetchHeatmap() async {
    try {
      final data = await SupabaseService.client.rpc(
        'get_user_presence_heatmap',
        params: {'p_radius_meters': hexRadiusMeters},
      );

      final rows = List<Map<String, dynamic>>.from(data as List? ?? const []);
      final maxCount = rows.fold<int>(1, (max, row) {
        final count = (row['user_count'] as num?)?.toInt() ?? 0;
        return count > max ? count : max;
      });

      _currentCells = rows.map((row) {
        final count = (row['user_count'] as num?)?.toInt() ?? 0;
        return HeatmapCell(
          cellId: row['cell_id'] as String,
          centerLat: (row['center_lat'] as num).toDouble(),
          centerLng: (row['center_lng'] as num).toDouble(),
          userCount: count,
          intensity: (count / maxCount).clamp(0.0, 1.0),
          level: _intensityLevel(count),
        );
      }).toList();

      _heatmapController.add(List.unmodifiable(_currentCells));
      AppLogger.debug('🔥 Heatmap: Loaded ${_currentCells.length} aggregate cells');
    } catch (e) {
      AppLogger.error('Heatmap: Failed to fetch aggregate cells: $e');
    }
  }

  static HeatmapLevel _intensityLevel(int count) {
    if (count >= 10) return HeatmapLevel.high;
    if (count >= 5) return HeatmapLevel.medium;
    return HeatmapLevel.low;
  }
}

class HeatmapCell {
  final String cellId;
  final double centerLat;
  final double centerLng;
  final int userCount;
  final double intensity;
  final HeatmapLevel level;

  const HeatmapCell({
    required this.cellId,
    required this.centerLat,
    required this.centerLng,
    required this.userCount,
    required this.intensity,
    required this.level,
  });

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is HeatmapCell &&
          other.cellId == cellId &&
          other.userCount == userCount;

  @override
  int get hashCode => Object.hash(cellId, userCount);
}

enum HeatmapLevel {
  high,

  medium,

  low,
}
