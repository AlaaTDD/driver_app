// lib/core/models/support_message_model.dart
import 'package:equatable/equatable.dart';

/// Type-safe model for the `support_messages` table.
///
/// IMPORTANT: Schema has only 4 columns: id, user_id, message, created_at.
/// There is NO `sender_role` column in the database.
/// The chatbot_repository.dart was incorrectly inserting `sender_role`.
///
/// To distinguish user vs support messages, we use the convention:
/// - User messages are stored normally via INSERT.
/// - AI/support replies are stored by the same INSERT (from same user).
/// - The distinction is tracked client-side only (not in DB schema).
class SupportMessageModel extends Equatable {
  final String id;
  final String userId;
  final String message;
  final DateTime createdAt;

  /// Client-side only flag — NOT stored in database.
  /// `true` if this message was sent by the user, `false` if it's a support reply.
  final bool isFromUser;

  const SupportMessageModel({
    required this.id,
    required this.userId,
    required this.message,
    required this.createdAt,
    this.isFromUser = true,
  });

  factory SupportMessageModel.fromJson(Map<String, dynamic> json) {
    return SupportMessageModel(
      id: json['id'] as String,
      userId: json['user_id'] as String,
      message: json['message'] as String? ?? '',
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'] as String)
          : DateTime.now(),
      // If sender_role exists (from a manually altered table), use it.
      // Otherwise default to true (user message).
      isFromUser: json['sender_role'] == null
          ? (json['_isUser'] as bool? ?? true)
          : (json['sender_role'] == 'user'),
    );
  }

  Map<String, dynamic> toInsertJson() {
    return {
      'user_id': userId,
      'message': message,
    };
  }

  @override
  List<Object?> get props => [id, userId, message, createdAt, isFromUser];
}
